# Appended to the graphics runtime env.sh.
RUNTIME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export XKB_BIN_DIRECTORY="$RUNTIME_DIR/bin"
export XKB_CONFIG_ROOT="$RUNTIME_DIR/share/X11/xkb"
export PATH="$RUNTIME_DIR/bin:$PATH"
